from classes import * 
from funcoes_do_jogo import *

game_loop()